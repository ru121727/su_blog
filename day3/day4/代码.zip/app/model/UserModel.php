<?php
/**
 * UserModel.php
 * Created by day11.
 * User: 苏小林
 * Date: 2016/5/29
 * Time: 15:00
 */

namespace app\model;


class UserModel extends \core\Model
{
    public $table = 'user';
}