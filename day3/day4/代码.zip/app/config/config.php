<?php

$config = array(
    'database' => array(
        'type' => 'mysql',
        'host' => 'localhost',
        'port' => '3306',
        'user' => 'root',
        'pass' => 'hahaha',
        'dbname' => 'php47',
        'charset' => 'utf8',
    ),
    // 邮件服务器配置
    'emailServe' => array(
        
    ),
);